module.exports = {
  print(obj, key) {
    return Object.entries(obj[key])
      .map(e => `${e[0]}: ${e[1]}`)
      .join("\n");
  },
  printObj(obj) {
    return Object.entries(obj)
      .map(e => `${e[0]}: ${e[1]}`)
      .join("\n");
  },

  getString(arr, key) {
    return arr
      .filter(e => e.key === key)
      .filter(e => !e.ready )
      .reduce(
        (acc, elem) => (acc += this.print(elem, key) + "\n  ============ \n"),
        "  ============ \n"
      );
  },
  toString(arr) {
    return arr
      .reduce(
        (acc, elem) => (acc += this.printObj(elem) + "\n  ============ \n"),
        "  ============ \n"
      );
  }
};
