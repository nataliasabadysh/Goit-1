### bot-father
    - ```
    /newbot
    ```
    - name for your bot: my-notes
    - username for your bot (end in `bot`): my_notes2019_bot

#### commands bot-father
- /newbot - create a new bot
- /mybots - edit your bots
- /token - generate authorization token
- /deletebot - delete a bot

token: numberOfToken

### npm
```bash
yarn init -y
yarn add telegraf dotenv
yarn add nodemon -D
```
- telegraf
- nodemon
- dotenv
```json
"scripts": {
  "start": "nodemon -r dotenv/config index.js"
}
  ```
### dotenv
.env
```
BOT_TOKEN=numberOfToken
```

### copy from 
[copy from Examples](https://www.npmjs.com/package/telegraf#user-content-examples)

### start server
```bash
yarn start
```

### search my_notes2019_bot
- search
- start
- hi //=> Hey there
- /help  //=> Send me a sticker
- stiker //=> 👍