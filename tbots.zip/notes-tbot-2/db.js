
const notes = [
    {
      key: "buy",
      buy: {
        батон: 1,
        "масло сливочное": "200грамм",
        кефир: "0.5"
      },
      ready: false
    },
    {
      key: "buy",
      buy: {
        "зубная паста": 1,
        "гель для душа": 1
      },
      ready: false
    },
    {
      key: "buy",
      buy: {
        "зубная щетка": 1,
        "стириральный порошек": '3кг'
      },
      ready: true
    },
    {
      key: "todo",
      todo: {
        'забрать заказ на "Новой почте"': 12345678
      },
      ready: false
    }
  ];

  module.exports = notes;