const Telegraf = require('telegraf');
const api = require('./helpers.js');

const bot = new Telegraf(process.env.BOT_TOKEN);

let notesArray = [
  {id: 'id-0', what: 'батон', quantity: 1},
  {id: 'id-1', what: 'масло сливочное', quantity: '200грамм'}
];

let note = {
  id: 'id-2',
  what: 'кефир',
  quantity: '1L',
}

bot.context.db = {
  getNotes: () => { return api.toString(notesArray) },
  setNotes: (obj) => { notesArray.push(obj)},
  delNotes: (id) => { notesArray = notesArray.filter(e => e.id !== id)},
  cteateNotes: (id, what, quantity) => ({
    id, what, quantity
   })
}

bot.command('list', (ctx) => {
  console.log('bot.command list');
  const note = ctx.db.getNotes()
  return ctx.reply(`${ctx.message.from.username}: ${note}`)
})
bot.command('add', (ctx) => {
  ctx.db.setNotes(note)
  return ctx.reply(`add to array`)
})
bot.command('remove', (ctx) => {
  ctx.db.delNotes('id-2');
  return ctx.reply(`remove from array`)
})
bot.command('cteate', (ctx) => {
  return ctx.reply(`See the next topic`)
})


bot.launch()