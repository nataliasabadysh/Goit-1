
ctx.update.update_id
ctx.update.callback_query.id
ctx.update.callback_query.id


{ message_id: 217,
  from:
   { id: 286263857,
     is_bot: false,
     first_name: 'Gennadiy',
     last_name: 'Gorbulin',
     username: 'gennadiy_gorbulin',
     language_code: 'en' },
  chat:
   { id: 286263857,
     first_name: 'Gennadiy',
     last_name: 'Gorbulin',
     username: 'gennadiy_gorbulin',
     type: 'private' },
  date: 1563021446,
  text: 'hello' }
