const notesArray = require("./notesArray.json");
const fs = require('fs');


console.log(Array.isArray(notesArray));