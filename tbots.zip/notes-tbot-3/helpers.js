module.exports = {
  printObj(obj) {
    return Object.entries(obj)
      .map(e => `${e[0]}: ${e[1]}`)
      .join("\n");
  },

  toString(arr) {
    return arr
      .reduce(
        (acc, elem) => (acc += this.printObj(elem) + "\n  ============ \n"),
        "  ============ \n"
      );
  }
};
