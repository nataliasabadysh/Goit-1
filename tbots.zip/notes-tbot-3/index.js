const Telegraf = require("telegraf");
const session = require("telegraf/session");
const Stage = require("telegraf/stage");
const Markup = require("telegraf/markup");
const WizardScene = require("telegraf/scenes/wizard");

const api = require("./helpers.js");
let notesArray = require("./notesArray.json");
let current = {
  id: null,
  index: -1,
  goods: null
};
let goods;

const callbackButtons = [
  Markup.callbackButton("View 🗒", "list"),
  Markup.callbackButton("Add 📝", "create"),
  Markup.callbackButton("Upd 🔄", "updateById"),
  Markup.callbackButton("Del 🗑", "deleteById")
];

const deleteById = new WizardScene(
  "deleteById",
  ctx => {
    ctx.reply("Для удаление напишите id товара.");
    return ctx.wizard.next(); // Переходим к следующему обработчику.
  },
  ctx => {
    const id = "" + ctx.message.text;
    notesArray.splice(notesArray.findIndex(e => "" + e[id] === id), 1);
    ctx.reply(
      "Выберите действие.",
      Markup.inlineKeyboard(callbackButtons).extra()
    );
    return ctx.scene.leave();
  }
);

const updateById = new WizardScene(
  "updateById",
  ctx => {
    ctx.reply("Для обновления напишите id товара.");
    return ctx.wizard.next(); // Переходим к следующему обработчику.
  },
  ctx => {
    current.id = "" + ctx.message.text;
    current.index = notesArray.findIndex(e => "" + e.id === current.id);
    current.goods = notesArray[current.index];
    ctx.reply("Этап 1: напишите названия товара.");
    return ctx.wizard.next(); // Переходим к следующему обработчику.
  },
  ctx => {
    ctx.reply("Этап 2: напишите количества товара.");
    current.goods.what = ctx.message.text;
    return ctx.wizard.next(); // Переходим к следующему обработчику.
  },

  ctx => {
    ctx.reply(
      "Выберите действие.",
      Markup.inlineKeyboard(callbackButtons).extra()
    );
    current.goods.quantity = ctx.message.text;
    current.id = null;
    current.index = -1;
    current.goods = null;
    return ctx.scene.leave();
  }
);

const create = new WizardScene(
  "create", // Имя сцены
  ctx => {
    ctx.reply("Этап 1: напишите названия товара.");
    return ctx.wizard.next(); // Переходим к следующему обработчику.
  },
  ctx => {
    ctx.reply("Этап 2: напишите количества товара.");
    goods = {};
    goods.id = "" + ctx.message.message_id;
    goods.what = ctx.message.text;
    return ctx.wizard.next(); // Переходим к следующему обработчику.
  },

  ctx => {
    ctx.reply(
      "Выберите действие.",
      Markup.inlineKeyboard(callbackButtons).extra()
    );
    goods.quantity = ctx.message.text;
    notesArray.push(goods);
    return ctx.scene.leave();
  }
);

const bot = new Telegraf(process.env.BOT_TOKEN);

bot.command("list", ctx => ctx.reply(api.toString(notesArray)));

const stage = new Stage();
stage.register(create);
stage.register(deleteById);
stage.register(updateById);
bot.use(session());
bot.use(stage.middleware());
bot.action("list", ctx => ctx.reply(api.toString(notesArray)));
bot.action("create", ctx => ctx.scene.enter("create"));
bot.action("deleteById", ctx => ctx.scene.enter("deleteById"));
bot.action("updateById", ctx => ctx.scene.enter("updateById"));
bot.start(ctx => {
  ctx.reply(
    "Выберите действие.",
    Markup.inlineKeyboard(callbackButtons).extra()
  );
});
bot.launch();
